/* mainController */

#import <Cocoa/Cocoa.h>

@interface mainController : NSObject
{
   // IBOutlet id commandList;
    IBOutlet id quitFinder;
    IBOutlet id restartDock;
    IBOutlet id stopDock;
    IBOutlet id startDock;
    IBOutlet id setName;
    IBOutlet id sheetControl;
    IBOutlet id startFinder;
	NSMutableArray * ddddList;
	int valueFromSheet;
    NSMenu *appDockMenu;
	NSImage	*myImage;
}

- (void)buildMenu;
- (IBAction)doCommand:(id)sender;
- (IBAction)doHelp:(id)sender;
- (IBAction)doRemove:(id)sender;
- (void)setValueFromSheet:(int)value;
- (int)valueFromSheet;

@end

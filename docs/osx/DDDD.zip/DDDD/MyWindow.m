#import "MyWindow.h"

@implementation MyWindow

- (id)initWithContentRect:(NSRect)contentRect styleMask:(unsigned int)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag
{
    NSWindow* result = [super initWithContentRect:contentRect 
										styleMask:NSBorderlessWindowMask
										  backing:NSBackingStoreBuffered defer:NO];

    [result setBackgroundColor: [NSColor clearColor]];
    [result setOpaque:NO];
    [result setHasShadow: YES];
 
	NSPoint wp;
	NSRect screenRect;
	int	mbarheight=[NSMenuView menuBarHeight];
	screenRect=[[NSScreen mainScreen] frame];
	wp.x=2;
	wp.y=screenRect.size.height-mbarheight-18;
	[self setFrameOrigin:wp];
	[self setLevel:NSFloatingWindowLevel];
    return result;
}

@end

#import "mainController.h"
#import "sheetController.h"

#define kFixedDockMenuAppKitVersion 632

@implementation mainController

- (NSMenu *)applicationDockMenu:(NSApplication *)sender
{
    return appDockMenu;
}

- (void)disabledIcon
{
	myImage= [NSImage imageNamed: @"disabled.tiff"];
	[NSApp setApplicationIconImage: myImage];
}

- (void)normalIcon:(id)sender;
{
	NSImage	*folderImage;
	if (sender!=nil)
		{		
		NSString *pathToDDDDs=[[NSMutableString alloc] initWithString:
			[[NSHomeDirectory() stringByAppendingPathComponent:@"DDDDs"] stringByAppendingPathComponent:[sender title]]];
		folderImage=[[NSImage alloc] initWithContentsOfFile:[pathToDDDDs stringByAppendingPathComponent:@"mapmage"]];
		}
	
	if (folderImage!=nil)
		myImage=folderImage;
	else
		myImage= [NSImage imageNamed: @"NSApplicationIcon"];
		
	[NSApp setApplicationIconImage: myImage];
}

- (IBAction)menuSelected:(id)sender
{
	BOOL ret;	
	NSAppleScript * script=[NSAppleScript alloc];
	
	if ([[ddddList objectAtIndex:0] isEqualToString:[sender title]])
		return;
	[self disabledIcon];
			
	[[appDockMenu itemWithTitle:[ddddList objectAtIndex:0]] setState:NSOffState];
		
	[script initWithSource:[quitFinder stringValue]];
	[script executeAndReturnError:nil];
		
	NSFileManager * folder=[[NSFileManager alloc] init];
	
	NSString *pathToDDDDs=[[NSMutableString alloc] initWithString:
							[NSHomeDirectory() stringByAppendingPathComponent:@"DDDDs"]];
		
	NSMutableString * pathToStorage=[[NSMutableString alloc] init];
		
	
	[pathToStorage setString:[pathToDDDDs stringByAppendingPathComponent:[ddddList objectAtIndex:0]]];
			
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/"]
				  toPath:[pathToStorage stringByAppendingPathComponent:@"Documents/"]
				  handler:nil];
		
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop/"]
					toPath:[pathToStorage stringByAppendingPathComponent:@"Desktop/"]
					handler:nil];

		///Library/Preferences/com.apple.dock.plist"
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.dock.plist"]
					  toPath:[pathToStorage stringByAppendingPathComponent:@"com.apple.dock.plist"]
					 handler:nil];
		///Library/Preferences/com.apple.finder.plist
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.finder.plist"]
					  toPath:[pathToStorage stringByAppendingPathComponent:@"com.apple.finder.plist"]
					 handler:nil];
		///Library/Preferences/com.apple.dashboard.plist
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.dashboard.plist"]
					  toPath:[pathToStorage stringByAppendingPathComponent:@"com.apple.dashboard.plist"]
					 handler:nil];
		
		///Library/Preferences/com.apple.sidebarlists.plist
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.sidebarlists.plist"]
					  toPath:[pathToStorage stringByAppendingPathComponent:@"com.apple.sidebarlists.plist"]
					 handler:nil];
	
	///Library/Preferences/com.apple.desktop.plist
	ret=[folder movePath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.desktop.plist"]
				  toPath:[pathToStorage stringByAppendingPathComponent:@"com.apple.desktop.plist"]
				 handler:nil];
	
	
	[pathToStorage setString:[pathToDDDDs stringByAppendingPathComponent:[sender title]]];

	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"Documents/"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/"] 
					  handler:nil];

	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"Desktop/"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop/"] 
					 handler:nil];
		///Library/Preferences/com.apple.dock.plist"

	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"com.apple.dock.plist"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.dock.plist"] 
					 handler:nil];
		///Library/Preferences/com.apple.dashboard.plist
	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"com.apple.dashboard.plist"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.dashboard.plist"] 
					 handler:nil];
		
		///Library/Preferences/com.apple.sidebarlists.plist
	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"com.apple.sidebarlists.plist"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.sidebarlists.plist"] 
					 handler:nil];
	
		///Library/Preferences/com.apple.finder.plist
	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"com.apple.finder.plist"]
					  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.finder.plist"] 
					 handler:nil];

	///Library/Preferences/com.apple.desktop.plist
	ret=[folder movePath:[pathToStorage stringByAppendingPathComponent:@"com.apple.desktop.plist"]
				  toPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Preferences/com.apple.desktop.plist"] 
				 handler:nil];
	
	[ddddList replaceObjectAtIndex:0 withObject:[sender title]];
	
	[script initWithSource:[startFinder stringValue]];
	[script executeAndReturnError:nil];
		
	[ddddList writeToFile:[NSHomeDirectory() 
				stringByAppendingPathComponent:@"DDDDs/DDDDs.plist"]
				atomically:YES];
		
	[[appDockMenu itemWithTitle:[ddddList objectAtIndex:0]] setState:NSOnState];
	
	NSString* launchThese=[[NSString alloc] initWithFormat:@"%s%@%s","do shell script \"head ",[pathToStorage stringByAppendingPathComponent:@"LaunchThese.txt"]," | xargs open\""];
	[script initWithSource:launchThese];
	[script executeAndReturnError:nil];
	
	
	[folder release];
	[self normalIcon:sender];
}

- (NSMenuItem *)constructMenuItem:(NSString *)title action:(SEL)aSelector menuTag:(int)tag
{
    NSMenuItem *item;

    if (NSAppKitVersionNumber>=kFixedDockMenuAppKitVersion)
    {
        item=[[[NSMenuItem alloc] initWithTitle:title action:aSelector keyEquivalent:@""] autorelease];
        [item setTarget:self];
		[item setTag:tag];
		[item setEnabled:YES];
    }
    else //we're running on an OS version that isn't fixed; use NSInvocation
    {
        //This invocation is going to be of the form aSelector
        NSInvocation *myInv=[NSInvocation invocationWithMethodSignature:[self methodSignatureForSelector:aSelector]];

        item=[[[NSMenuItem alloc] initWithTitle:title action:@selector(invoke) keyEquivalent:@""] autorelease];

        //This invocation is going to be an invocation of aSelector
        [myInv setSelector:aSelector];
        //This invocation is going to send its message to self
        [myInv setTarget:self];
        [myInv setArgument:&item atIndex:2];
		[item setTarget:[myInv retain]];
        [item setTag:tag];
        [item setEnabled:YES];
    }

    return item;
}

- (void)buildMenu
{
    int numItems = [appDockMenu numberOfItems];
	int loop;
    while (numItems--)
    {
        if (NSAppKitVersionNumber<kFixedDockMenuAppKitVersion)
			[[[appDockMenu itemAtIndex: 0] target] release];
        
        [appDockMenu removeItemAtIndex: 0];
    }
	 
	if([ddddList count]>0)
	{
		for(loop=1;loop<[ddddList count];loop++)
			[appDockMenu addItem:[self constructMenuItem:[ddddList objectAtIndex:loop] action:@selector(menuSelected:) menuTag:0]];

		[appDockMenu addItem:[NSMenuItem separatorItem]];
		[appDockMenu addItem:[self constructMenuItem:@"New with empty" action:@selector(doCommand:) menuTag:-1]];
		[appDockMenu addItem:[self constructMenuItem:@"Clone" action:@selector(doCommand:) menuTag:-2]];
		[appDockMenu addItem:[self constructMenuItem:@"Remove" action:@selector(doRemove:) menuTag:-3]];

		[[appDockMenu itemWithTitle:[ddddList objectAtIndex:0]] setState:NSOnState];
	}
}

- (IBAction)doHelp:(id)sender
{
	NSAppleScript * script=[NSAppleScript alloc];
	NSString *pathToHelp =[[NSBundle mainBundle] pathForResource:@"DDDD Help" ofType:@"rtfd"];
	
	[script initWithSource:[[@"tell app \"finder\"\r open (\"" stringByAppendingString:pathToHelp]
							stringByAppendingString:@"\" as POSIX file)\r end tell \r"]];
	[script executeAndReturnError:nil];
							
}

- (void)setValueFromSheet:(int)value
{
	valueFromSheet=value;
}

- (int)valueFromSheet
{
	return valueFromSheet;
}

- (IBAction)doRemove:(id)sender
{
	int	removeLoop;
	if ([[ddddList objectAtIndex:0] isEqualToString:@"STARTUP"])
		return;
	
	if([ddddList count]>0)
	{
		for(removeLoop=1;removeLoop<[ddddList count];removeLoop++)
		{
			if([[ddddList objectAtIndex:removeLoop] isEqualToString:[ddddList objectAtIndex:0]])
			{
				[ddddList removeObjectAtIndex:removeLoop];
				[sender setTitle:@"STARTUP"];
				[self menuSelected:sender];
			}
		}
	}
	
	[ddddList writeToFile:[NSHomeDirectory() 
				stringByAppendingPathComponent:@"DDDDs/DDDDs.plist"]
			   atomically:YES];
	
	[self buildMenu];
}

- (IBAction)doCommand:(id)sender
{

	valueFromSheet=-1;
	NSFileManager * folder=[[NSFileManager alloc] init];
	NSMutableString * folderName=[[NSMutableString alloc] initWithString:[NSHomeDirectory() 
									stringByAppendingPathComponent:@"DDDDs/"]];

	if([sender tag]<0)
	{
		[sheetControl showSheet:nil];

		if(valueFromSheet==1)
		{	
			folderName=(NSMutableString*)[folderName stringByAppendingPathComponent:[setName stringValue]];
			folderName=(NSMutableString*)[folderName stringByAppendingString:@"/"];
			[folder createDirectoryAtPath:folderName attributes:nil];
		
			switch ([sender tag])
			{
				case -1:
					[folder createDirectoryAtPath:[folderName stringByAppendingPathComponent:@"Documents"] attributes:nil];
					[folder createDirectoryAtPath:[folderName stringByAppendingPathComponent:@"Desktop"] attributes:nil];
					[ddddList addObject:[setName stringValue]];
					break;
				case -2:
					[self disabledIcon];
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]
									toPath:[folderName stringByAppendingPathComponent:@"Documents"]
									handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Desktop"]
									toPath:[folderName stringByAppendingPathComponent:@"Desktop"]
									handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"/Library/Preferences/com.apple.dock.plist"]
							  toPath:[folderName stringByAppendingPathComponent:@"com.apple.dock.plist"]
							 handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"/Library/Preferences/com.apple.finder.plist"]
							  toPath:[folderName stringByAppendingPathComponent:@"com.apple.finder.plist"]
							 handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"/Library/Preferences/com.apple.dashboard.plist"]
							  toPath:[folderName stringByAppendingPathComponent:@"com.apple.dashboard.plist"]
							 handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"/Library/Preferences/com.apple.sidebarlists.plist"]
							  toPath:[folderName stringByAppendingPathComponent:@"com.apple.sidebarlists.plist"]
							 handler:nil];
					
					[folder copyPath:[NSHomeDirectory() stringByAppendingPathComponent:@"/Library/Preferences/com.apple.desktop.plist"]
							  toPath:[folderName stringByAppendingPathComponent:@"com.apple.desktop.plist"]
							 handler:nil];
					
					[ddddList addObject:[setName stringValue]];
					break;
				case -3:
					break;
			}//end swtch

			[self buildMenu];
		}//end if
	}//end if

	[ddddList writeToFile:[NSHomeDirectory() 
				stringByAppendingPathComponent:@"DDDDs/DDDDs.plist"]
				atomically:YES];
	
	[folder release];
	[self normalIcon:sender];

}

- (void)awakeFromNib
{
	NSFileManager * folder=[[NSFileManager alloc] init];
	[self disabledIcon];

	ddddList=[[NSMutableArray alloc] initWithContentsOfFile:[NSHomeDirectory() 
									stringByAppendingPathComponent:@"DDDDs/DDDDs.plist"]];
	if(ddddList==nil)
		ddddList=[[NSMutableArray alloc] init];
	
	if([ddddList count]==0)
	{
		[folder createDirectoryAtPath:[NSHomeDirectory() 
									stringByAppendingPathComponent:@"DDDDs"] attributes:nil];
		[folder createDirectoryAtPath:[NSHomeDirectory() 
									stringByAppendingPathComponent:@"DDDDs/STARTUP/"] attributes:nil];
		[ddddList addObject:@"STARTUP"];
		[ddddList addObject:@"STARTUP"];
		[ddddList writeToFile:[NSHomeDirectory() 
									stringByAppendingPathComponent:@"DDDDs/DDDDs.plist"]
									atomically:YES];
	}

	appDockMenu=[[NSMenu alloc] initWithTitle:@"DockMenu"];
    [appDockMenu setAutoenablesItems:NO];
	[self buildMenu];
	[folder release];
	[self normalIcon:0];
}


@end

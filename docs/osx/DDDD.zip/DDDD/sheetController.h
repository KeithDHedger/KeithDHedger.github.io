/* sheetController */

#import <Cocoa/Cocoa.h>

@interface sheetController : NSObject
{
    IBOutlet id commandControl;
    IBOutlet id ddddName;
    IBOutlet id mainWindow;
    IBOutlet id sheetWindow;
}
- (IBAction)endSheet:(id)sender;
- (IBAction)showSheet:(id)sender;
@end

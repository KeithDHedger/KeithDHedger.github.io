#import "sheetController.h"
#import "mainController.h"

@implementation sheetController

- (IBAction)endSheet:(id)sender
{
	[NSApp stopModal];
	[commandControl setValueFromSheet:[sender tag]];
	[sheetWindow orderOut:sender];
	[NSApp endSheet:sheetWindow returnCode:[sender tag]];

}

- (IBAction)showSheet:(id)sender
{
	[NSApp runModalForWindow:sheetWindow];
}

@end

#import "MyImageView.h"

@implementation MyImageView


- (BOOL)performDragOperation:(id )sender
{
	NSPasteboard *paste = [sender draggingPasteboard];
    NSArray *types = [NSArray arrayWithObjects:NSTIFFPboardType,NSFilenamesPboardType, nil];
    NSString *desiredType = [paste availableTypeFromArray:types];
	if(desiredType==nil)
		return NO;
    NSData *carriedData = [paste dataForType:desiredType];

    if (nil == carriedData)
    {
        NSRunAlertPanel(@"Paste Error", @"Sorry, but the past operation failed",nil, nil, nil);
        return NO;
    }
    else
    {
        if ([desiredType isEqualToString:NSTIFFPboardType])
        {
            NSImage *newImage = [[NSImage alloc] initWithData:carriedData];
            [self setImage:newImage];
            [newImage release];    
        }
        else if ([desiredType isEqualToString:NSFilenamesPboardType])
        {
			NSArray *fileArray = 
			[paste propertyListForType:@"NSFilenamesPboardType"];
			filePath= [fileArray objectAtIndex:0];
        }
        else
        {
            NSAssert(NO, @"This can't happen");
            return NO;
        }
    }
    return YES;
}

- (NSString*)pathToFile
{
	return filePath;
}


@end

#import "mainController.h"

@implementation mainController

- (IBAction)doSplit:(id)sender
{

	NSPoint	p=NSMakePoint(0,0);
	NSRect	r=NSMakeRect(0,50,50,50);
	NSImage *im;
	NSImage *im2;
//	bigPic=[[NSImage init]alloc];
//	bigPic=[mainImage image];
	//r.origin.x=0;
	//r.origin.y=0;
//	r.size.width=100;
	//r.size.height=100;
//	im=[[NSImage alloc] initWithContentsOfFile:@"/Volumes/Data/Downloads/london/central/central06.jpg"];
	im=[[NSImage alloc] init];
	//im2=[[NSImage alloc] initWithContentsOfFile:@"/Volumes/Data/Downloads/london/central/central01.jpg"];
	im2=[[NSImage alloc] initWithSize:NSMakeSize ( 200, 200 )];
	
	im=[mainImage image];
	//[pic02 setImage:[mainImage image]];
	//[im setImage:[mainImage image]];
//	[im drawAtPoint:p fromRect:r operation:NSCompositeCopy fraction:0.0];
	//[pic02 setImage:[(NSImage*)[pic02 image] drawAtPoint:p fromRect:r operation:NSCompositeCopy fraction:0.0]];
//	[pic02 setImage:[[mainImage image] drawAtPoint:p fromRect:r operation:NSCompositeCopy fraction:0.0]];
	//	
//	[im setCacheMode:NSImageCacheNever];
	[im2 lockFocus];
	[(NSImage*)[mainImage image] compositeToPoint:p fromRect:r operation:NSCompositeSourceOver];
	//[pic02 setImage:im];
	[im2 unlockFocus];
	[pic02 setImage:im2];

}

@end

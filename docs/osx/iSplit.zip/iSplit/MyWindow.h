/* MyWindow */

#import <Cocoa/Cocoa.h>

@interface MyWindow : NSWindow
{
}
@end

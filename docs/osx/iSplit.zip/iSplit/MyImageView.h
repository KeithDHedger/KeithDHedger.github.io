/* MyImageView */

#import <Cocoa/Cocoa.h>

@interface MyImageView : NSImageView
{
//	NSImage *_ourImage;
	NSString *filePath;
}
//- (void)setImage:(NSImage *)newImage;
//- (NSImage *)image;
//- (void)draggingEnded:(id )sender;
- (NSString*)pathToFile;

@end

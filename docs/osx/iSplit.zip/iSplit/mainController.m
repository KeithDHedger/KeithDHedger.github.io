#import "mainController.h"
#import "MyImageView.h"
@implementation mainController


- (IBAction)doDrop:(id)sender
{
	[(NSWindow*)pic02 setTitle:[pic01 pathToFile]];
	path=[[[pic01 pathToFile] stringByDeletingPathExtension] retain];
	name=[[[[pic01 pathToFile] lastPathComponent] stringByDeletingPathExtension] retain];
	fold=[[[path stringByDeletingLastPathComponent] stringByAppendingPathComponent:[name stringByAppendingString:@"split"]] retain];
}

- (IBAction)doSplit:(id)sender
{
	
	NSFileManager *fileHandle;
	NSRect	r;
	NSImage *im;
	NSImage *im2;
	int xloop,yloop;
	float xoffset,yoffset;
	
	im=[[NSImage alloc] init];
	im=[mainImage image];
	fileHandle=[[NSFileManager alloc] init];
	[fileHandle createDirectoryAtPath:fold attributes:nil];
	xoffset=[[mainImage image] size].width/5.0;
	yoffset=[[mainImage image] size].height/5.0;
	r=NSMakeRect(0,0,xoffset,yoffset);
	for (yloop=4;yloop>-1;yloop--)
	{
		r.origin.x=0;
		for (xloop=0;xloop<5;xloop++)
		{
			im2=[[NSImage alloc] initWithSize:NSMakeSize ( 220, 176 )];
			[im2 lockFocus];
			[(NSImage*)[mainImage image] drawInRect:NSMakeRect(0,0,220,176) fromRect:r operation:NSCompositeSourceOver fraction:1];
			[im2 unlockFocus];
	
			[(NSImageView*)[pic11 cellAtRow:yloop column:xloop] setImage:im2];
						
			[[[(NSImageView*)[pic11 cellAtRow:yloop column:xloop] image] TIFFRepresentation]
			writeToFile:(NSString*)[NSString stringWithFormat:@"%@/%@%d.tiff",fold,name,100+(xloop+(5*yloop)),nil]  atomically:YES];

			r.origin.x=r.origin.x+xoffset;
			[im2 release];
		}
		r.origin.y=r.origin.y+yoffset;
	}
	[pic11 display];
	
	
}


@end

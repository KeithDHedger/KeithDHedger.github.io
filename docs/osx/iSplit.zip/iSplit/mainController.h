/* mainController */

#import <Cocoa/Cocoa.h>

@interface mainController : NSObject
{
	NSImage		*bigPic;
    IBOutlet id mainImage;
    IBOutlet id pic01;
    IBOutlet id pic02;
    IBOutlet id pic03;
    IBOutlet id pic04;
    IBOutlet id pic05;
    IBOutlet id pic06;
    IBOutlet id pic07;
    IBOutlet id pic08;
    IBOutlet id pic09;
    IBOutlet id pic10;
    IBOutlet id pic11;
    IBOutlet id pic12;
    IBOutlet id pic13;
    IBOutlet id pic14;
    IBOutlet id pic15;
    IBOutlet id pic16;
    IBOutlet id pic17;
    IBOutlet id pic18;
    IBOutlet id pic19;
    IBOutlet id pic20;
    IBOutlet id pic21;
    IBOutlet id pic22;
    IBOutlet id pic23;
    IBOutlet id pic24;
    IBOutlet id pic25;
	
	NSString *	path;
	NSString *	fold;
	NSString *	name;
}
- (IBAction)doDrop:(id)sender;
- (IBAction)doSplit:(id)sender;

@end

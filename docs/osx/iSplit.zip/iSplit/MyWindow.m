#import "MyWindow.h"

@implementation MyWindow
- (void)close
{
	[NSApp terminate:self];
}
@end

#import <Foundation/Foundation.h>


int main (int argc, const char * argv[])
{

	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int		retCode=1;
	int		loop;
	BOOL	isApp=true;
	int		offSet=0;

	NSString * flags=[[NSString alloc] initWithUTF8String:argv[1]];
	NSMutableString * pathToApp=[[NSMutableString alloc] init];
	NSMutableString * prefsName=[[NSMutableString alloc] init];

	if ([flags isEqualToString:@"--prefs"])
	{
		isApp=false;
		offSet=1;
	}
	
	if(argc>1)
	{
		for (loop=1+offSet;loop<argc;loop++)
		{
			NSString * fileName =[[NSString alloc] initWithUTF8String:argv[loop]];
			if(isApp==true)
			{
				if([fileName isAbsolutePath])
				{
					[pathToApp setString:fileName];
				}
				else
				{
					[pathToApp setString:@"/Applications"];
					[pathToApp setString:[pathToApp stringByAppendingPathComponent:fileName]];
				}
				[pathToApp setString:[pathToApp stringByAppendingPathExtension:@"app"]];
				[pathToApp setString:[pathToApp stringByAppendingPathComponent:@"Contents/Info.plist"]];
				NSDictionary *infoFile=[[NSDictionary alloc] initWithContentsOfFile:pathToApp];
				if(infoFile!=NULL)
				{
					printf("%s%s%s%s\n", [[infoFile valueForKey:@"CFBundleShortVersionString"] UTF8String],"("
							   ,[[infoFile valueForKey:@"CFBundleVersion"] UTF8String],")");
					retCode=0;
				}
					
				}//end if isapp=true
			else
			{
				[prefsName setString:[NSString  stringWithFormat:@"/Library/PreferencePanes/%@",fileName,nil]];
				[prefsName setString:[prefsName stringByAppendingPathExtension:@"prefPane"]];
				[prefsName setString:[prefsName stringByAppendingPathComponent:@"Contents/Info.plist"]];
				
				[pathToApp setString:[NSString  stringWithFormat:@"~%@",prefsName,nil]];
				[pathToApp setString:[pathToApp stringByExpandingTildeInPath]];
				NSDictionary *infoFile=[[NSDictionary alloc] initWithContentsOfFile:pathToApp];
				if(infoFile!=NULL)
				{
					printf("%s%s%s%s\n", [[infoFile valueForKey:@"CFBundleShortVersionString"] UTF8String],"("
							   ,[[infoFile valueForKey:@"CFBundleVersion"] UTF8String],")");
					retCode=0;
				}//user
				else
				{
					NSDictionary *infoFile=[[NSDictionary alloc] initWithContentsOfFile:prefsName];
					if(infoFile!=NULL)
					{
						printf("%s%s%s%s\n", [[infoFile valueForKey:@"CFBundleShortVersionString"] UTF8String],"("
								   ,[[infoFile valueForKey:@"CFBundleVersion"] UTF8String],")");
						retCode=0;
					}//all users
					else
					{
						[pathToApp setString:[NSString  stringWithFormat:@"/System%@",prefsName,nil]];
						NSDictionary *infoFile=[[NSDictionary alloc] initWithContentsOfFile:pathToApp];
						if(infoFile!=NULL)
						{
							printf("%s%s%s%s\n", [[infoFile valueForKey:@"CFBundleShortVersionString"] UTF8String],"("
									   ,[[infoFile valueForKey:@"CFBundleVersion"] UTF8String],")");
							retCode=0;
						}//system
					}//cant find
				}//end prefs
					
			}//end is app
					
		}//end for
	}//end argc
	[pool release];
	return retCode;
}


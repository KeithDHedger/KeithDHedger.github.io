
OSStatus LoadFrameworkBundle(CFStringRef framework, CFBundleRef *bundlePtr);

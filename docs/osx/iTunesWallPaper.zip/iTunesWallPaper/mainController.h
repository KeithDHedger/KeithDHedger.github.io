/* mainController */

#import <Cocoa/Cocoa.h>

@interface mainController : NSObject
{
    IBOutlet id debugWell;
    IBOutlet id mainView;
	NSImage * pic;
	BOOL	flickPic;
	NSTimer* lightswitch;
	NSString *def;
}
- (IBAction)doHelp:(id)sender;
- (IBAction)updateArtwork:(id)sender;
- (IBAction)updateDesktop:(id)sender;
- (NSImage*)getPic;
@end

/* myDelegate */

#import <Cocoa/Cocoa.h>

@interface myDelegate : NSObject
{
    IBOutlet id mainCont;
}
@end

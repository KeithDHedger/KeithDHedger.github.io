#import "mainController.h"


@implementation mainController

- (NSImage*)getPic
{
	return pic;
}

- (IBAction)setDesktop:(NSString *)picturePath
{
	NSString *script;
	NSAppleScript * appleScript=[NSAppleScript alloc];
	script=[[NSString alloc] initWithFormat:@"%s%@%s","tell application \"Finder\" to set the desktop picture to ((\"",
		picturePath,"\") as POSIX file)",nil];
	
	[appleScript initWithSource:script];
	[appleScript executeAndReturnError:nil];
	
}

- (IBAction)updateDesktop:(id)sender
{
	[self setDesktop:def];
	[NSApp terminate:self];
}

- (IBAction)doHelp:(id)sender
{
	NSAppleScript * script=[NSAppleScript alloc];
	NSString *pathToHelp =[[NSBundle mainBundle] pathForResource:@"iTunesWallPaper Help" ofType:@"rtfd"];
	
	[script initWithSource:[[@"tell app \"finder\"\r open (\"" stringByAppendingString:pathToHelp]
		stringByAppendingString:@"\" as POSIX file)\r end tell \r"]];
	[script executeAndReturnError:nil];
	
}

- (IBAction)updateArtwork:(id)sender
{
	NSString *pathToScript;
	NSAppleScript *getArt=[NSAppleScript alloc];
	NSData *picData=[NSData alloc];
	NSAppleEventDescriptor *aDesc;
	
	pathToScript=[[NSBundle mainBundle] pathForResource:@"getArtwork" ofType: @"scpt"];
	[getArt initWithContentsOfURL:[NSURL fileURLWithPath:pathToScript] error:nil];
	aDesc=[getArt executeAndReturnError:nil];
	picData=[aDesc data];
	if (picData!=nil)
		{
		[pic release];
		pic=[[NSImage alloc] initWithData:picData];
		[pic retain];
		if(flickPic==NO)
			{
			[[pic TIFFRepresentation] writeToFile:@"/tmp/mypic1.pict" atomically:YES];
			[self setDesktop:@"/tmp/mypic1.pict"];
			}
		else
			{
			[[pic TIFFRepresentation] writeToFile:@"/tmp/mypic.pict" atomically:YES];
			[self setDesktop:@"/tmp/mypic.pict"];
			}
		flickPic=!flickPic;
		}
}

-(void)awakeFromNib
{
	
	NSDictionary *dict;
	def=[NSString alloc];
	dict=[[NSDictionary alloc] initWithContentsOfFile:[@"~/Library/Preferences/com.apple.desktop.plist" stringByStandardizingPath]];
	def=[[[dict objectForKey:@"Background"] objectForKey:@"default"] objectForKey:@"ImageFilePath"];
	
	[self updateArtwork:nil];
	lightswitch = [NSTimer scheduledTimerWithTimeInterval:20 target:self selector:@selector(updateArtwork:) userInfo:nil repeats:YES];
}

@end

#import "myDelegate.h"
#import "mainController.h"

@implementation myDelegate

- (void)applicationWillTerminate:(NSNotification *)notification
{
	[[[NSFileManager alloc] init] removeFileAtPath:@"/tmp/mypic1.pict" handler:nil];
	[[[NSFileManager alloc] init] removeFileAtPath:@"/tmp/mypic.pict" handler:nil];
	[mainCont updateDesktop:nil];
}

@end

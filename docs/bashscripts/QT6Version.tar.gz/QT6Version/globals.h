

#include <QCoreApplication>
#include <QDir>
#include <QProcess>

#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <signal.h>

#define MINFILESIZE 20000000
#define ATTRSTRINGLEN 10

enum colourNames{BLACK=0,RED,GREEN,YELLOW,BLUE,MAGENTA,CYAN,WHITE};

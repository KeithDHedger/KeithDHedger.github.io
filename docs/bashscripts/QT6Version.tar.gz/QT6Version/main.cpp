

#include "globals.h"

struct fileData
{
	QString srcFile;
	QString destFolder;
	QString destFile;
};

QVector<fileData>	dataList={};
QString				destDir="";
QString				subtractDir="";
bool					useCurses=true;
unsigned int			realFileCnt=0;
unsigned int			copiedFiles=0;

int					termRows=24;
int					termCols=80;

int					boxHite=13;
int					boxWidth=0;
int					middleX=0;
int					middleY=0;

const char			*HBar="─";
const char			*VBar="│";
const char			*upperLeft="┌";
const char			*upperRite="┐";
const char			*lowerLeft="└";
const char			*lowerRite="┘";

const char			*dialogName="ViCp";
qint64				pid=-1;
bool					oneFile=false;

bool NOGUI = false;
bool RECURSIVE = false;

void updateTermSize()
{
	struct winsize	w{};

	if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&w)==0)
		{
			termRows=w.ws_row;
			termCols=w.ws_col;
		}
}

void hideCursor()
{
	QTextStream(stdout)<<"\e[?25l";
	fflush(NULL);
}
 
void showCursor()
{
	QTextStream(stdout)<<"\e[?25h";
	fflush(NULL);
}

void putCursor(int x,int y)
{
	QTextStream(stdout)<<QString("\e[%1;%2H").arg(y).arg(x);
	fflush(NULL);
}

void clearTerm(void)
{
	QTextStream(stdout)<<QString("\e[2J\e[H");
	fflush(NULL);
}

void resetAttrs()
{
	QTextStream(stdout)<<QString("\e[0m");
	fflush(NULL);
}

void makeTermSane()
{
	termios	t;

	showCursor();
	resetAttrs();
// restore terminal
	if(tcgetattr(STDIN_FILENO,&t)==0)
		{
			t.c_lflag|=(ECHO|ICANON);
			tcsetattr(STDIN_FILENO,TCSANOW,&t);
		}
}

QString setColor(QString col)
{
	if(col=="BOLDCYAN")
		return(QString("\e[1;36;46m"));
	if(col=="BOLDYELLOWONCYAN")
		return(QString("\e[1;33;46m"));
	if(col=="BLACKONCYAN")
		return(QString("\e[0;30;46m"));

	return("\e[0m");
}

void setColours(int bold,colourNames forecol,colourNames backcol,bool britefore=false)
{
	int	dobrightfore=30;
	if(britefore==true)
		dobrightfore=90;
	dobrightfore+=forecol;
	QTextStream(stdout)<<QString("\e[%1;%2;4%3m").arg(bold).arg(dobrightfore).arg(backcol);
}

void drawBar(int x,int y,int w)
{
	putCursor(x,y);
	for(int i=0;i<w;i++)
		QTextStream(stdout)<<" ";
}

void drawHLine(int x,int y,int w,const char *chr=HBar)
{
	putCursor(x,y);
	for(int i=0;i<w;i++)
		QTextStream(stdout)<<chr;
}

void drawVLine(int x,int y,int h,const char *chr=VBar)
{
	for(int i=0;i<h;i++)
		{
			putCursor(x,y+i);
			QTextStream(stdout)<<chr;
		}
}

void drawBox(int startx,int starty,int width,int hite,bool shadow=false)
{
	int			bold=0;
	colourNames	forcoltop=BLACK;
	colourNames	forcolbottom=WHITE;
	bool			dotopbrite=false;
	bool			dobotbrite=true;
	if(shadow==true)
		{
			forcoltop=WHITE;
			forcolbottom=BLACK;
			dotopbrite=true;
			dobotbrite=false;
		}

	setColours(bold,forcoltop,CYAN,dotopbrite);
	putCursor(startx,starty);
	QTextStream(stdout)<<upperLeft;

	drawHLine(startx+1,starty,width-2);
	QTextStream(stdout)<<upperRite;
	for(int hfor=1;hfor<hite-1;hfor++)
		{
			putCursor(startx,starty+hfor);
			setColours(bold,forcoltop,CYAN,dotopbrite);
			QTextStream(stdout)<<VBar;

			for(int wfor=0;wfor<width-2;wfor++)
				QTextStream(stdout)<<" ";
			
			setColours(bold,forcolbottom,CYAN,dobotbrite);
			QTextStream(stdout)<<VBar;
		}
	putCursor(startx,hite+starty-1);
	setColours(bold,forcolbottom,CYAN,dobotbrite);
	QTextStream(stdout)<<lowerLeft;
	drawHLine(startx+1,starty+hite-1,width-2);
	QTextStream(stdout)<<lowerRite;
	if(shadow==true)
		{
			setColours(0,BLACK,BLACK);
			drawHLine(startx+1,starty+boxHite,boxWidth," ");
			drawVLine(startx+boxWidth,starty+1,boxHite," ");
		}
	fflush(NULL);
}

void drawProgressBar(int startx,int starty,int wid,double val,double min,double max,bool justupdate=false)
{
	QString percent;
	int percval=(int)(val/max*100);

	if(justupdate==false)
		drawBox(startx,starty,wid,3);

	percent=QString("%1%").arg(percval);	

	if(percval<0)
		percent="0%";
	if(percval>100)
		percent="100%";

	putCursor(startx+(wid/2)-(percent.length()/2),starty);
	setColours(1,YELLOW,CYAN);
	QTextStream(stdout)<<percent;
	QTextStream(stdout)<<QString("\e[%1;3%2;10%3m").arg(1).arg(YELLOW).arg(YELLOW);
	double numsects=(double)((double)wid-2)/(1+(double)max-(double)min);
	drawBar(startx+1,starty+1,numsects*val);
	fflush(NULL);
}

void setOverallProgress(double cnt,double of,bool justupdate=false)
{
	if(oneFile==true)
		return;
	QString	str;
	int		boxx=(termCols/2)-(boxWidth/2)+3;
	int		boxy=(termRows/2)-(boxHite/2);

	putCursor(boxx,boxy+1);
	str=QString("%3File%4 %1 %3Of%4 %2").arg(cnt).arg(of).arg(setColor("BOLDYELLOWONCYAN")).arg(setColor("BLACKONCYAN"));
	QTextStream(stdout)<<str.leftJustified(boxWidth-3+ATTRSTRINGLEN*4,' ');

	putCursor(boxx,boxy+2);
	QTextStream(stdout)<<QString("%1Overall Progress").arg(setColor("BOLDYELLOWONCYAN"));

	drawProgressBar(boxx,boxy+3,boxWidth-4,cnt,1,of,justupdate);
}

QString setLen(QString str,int maxlen)
{
	QString retstr=str;
	if (retstr.length()> maxlen)
		{
			int		halfLength=(maxlen-3)/2;

			QString	firstPart=retstr.mid(0,halfLength);
			QString	secondPart=retstr.mid(retstr.length()-halfLength);
			retstr=firstPart+"..."+secondPart;
		}

	return(retstr);
}

void setFileProgress(qint64 cnt,qint64 of,QString from,QString to,bool justupdate=false)
{
	QString	str;
	int		boxx=(termCols/2)-(boxWidth/2)+3;
	int		boxy=(termRows/2)-(boxHite/2)+6;

	int		correctedy=boxy;
	if(oneFile==true)
		correctedy-=5;

	putCursor(boxx,correctedy);
	str=from;
	str=setLen(from,boxWidth-(5+4));
	str=QString("%1From:%2%3").arg(setColor("BOLDYELLOWONCYAN")).arg(setColor("BLACKONCYAN")).arg(str);
	QTextStream(stdout)<<str.leftJustified(boxWidth-4+ATTRSTRINGLEN*2,' ',true);

	putCursor(boxx,correctedy+1);
	str=to;
	str=setLen(to,boxWidth-(3+4));
	str=QString("%1To:%2%3").arg(setColor("BOLDYELLOWONCYAN")).arg(setColor("BLACKONCYAN")).arg(str);
	QTextStream(stdout)<<str.leftJustified(boxWidth-4+ATTRSTRINGLEN*2,' ',true);

	putCursor(boxx,correctedy+2);
	str=QString("%1Copied%2 %3 %1Of%2 %4").arg(setColor("BOLDYELLOWONCYAN")).arg(setColor("BLACKONCYAN")).arg(cnt).arg(of);
	QTextStream(stdout)<<str.leftJustified(boxWidth-4+ATTRSTRINGLEN*4,' ',true);

	drawProgressBar(boxx,correctedy+3,boxWidth-4,cnt,1,of,justupdate);
}

void drawDialog(void)
{
	int boxx=(termCols/2)-(boxWidth/2)+1;
	int boxy=(termRows/2)-(boxHite/2);

//background
	setColours(0,WHITE,BLUE);
	fflush(NULL);
	clearTerm();
	putCursor(0,2);
	drawHLine(0,2,termCols);
	putCursor(termCols/2-2,0);
	setColours(1,WHITE,BLUE);
	QTextStream(stdout)<<dialogName;

//main box
	drawBox(boxx,boxy,boxWidth,boxHite,true);
}

void resetTerminal()
{
	updateTermSize();
    boxWidth=termCols-12;
    middleX=termCols/2;
    middleY=termRows/2;

   // if (!NOGUI) {
       // draw_dialog_box(boxWidth, boxHite, DIALOGNAME);
	drawDialog();
	setFileProgress(0,1,"","");
      //  putCursor(middleX - 8, middleY - (boxHite / 2));
      //  std::cout << col(1, 3, 6) << DIALOGMESSAGE << " Files..." << std::flush;
  //  }
}

void drawDialogWrap(void)
{
	resetTerminal();
}

void checkTermSize(void)
{
	bool				changed=false;
	struct winsize	w{};

	if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&w)==0)
		{
			if(w.ws_row!=termRows || w.ws_col!=termCols)
				changed=true;
		}

	if(changed==true)
		{
			resetTerminal();	
			setOverallProgress((double)copiedFiles,(double)realFileCnt);
		}
}

void copyFile(fileData data)
{
	QString			destpath;
	QString			srcpath;
	qint64			srcsize;
	QString			tempfile;
	QProcess			cpproc;
	QProcess			backgroundcoms;
	QProcess			foregroundcoms;

	destpath=data.destFolder+"/"+data.destFile;
	//printf("\n%s->%s\n",qPrintable(data.srcFile),qPrintable(destpath));
	tempfile=QString("%1.%2").arg(destpath).arg(qHash(destpath));

	backgroundcoms.setStandardOutputFile(QProcess::nullDevice());
	backgroundcoms.setStandardErrorFile(QProcess::nullDevice());

	foregroundcoms.setStandardOutputFile(QProcess::nullDevice());
	foregroundcoms.setStandardErrorFile(QProcess::nullDevice());

	backgroundcoms.setProgram("rm");
	backgroundcoms.setArguments({tempfile});

	if(QFileInfo::exists(tempfile)==true)
		{
			QFile	file(tempfile);

			if(file.open(QIODevice::Truncate | QIODevice::WriteOnly))
				file.close();
		}

	foregroundcoms.setProgram("mv");
	foregroundcoms.setArguments({destpath,tempfile});
	foregroundcoms.start();
	foregroundcoms.waitForFinished(-1);

	pid=-1;

	if(QFileInfo(data.srcFile).isReadable()==false)
		{
			showCursor();
			putCursor(1,termRows);
			makeTermSane();
			if(pid!=-1)
				kill(pid,SIGTERM);
			QTextStream(stderr)<<QString("Can't read file \"%1\" ...").arg(data.srcFile)<<Qt::endl;
			exit(0);			
		}
	QProcess::startDetached("cp",{"--no-dereference","--preserve",data.srcFile,data.destFolder},getenv("PWD"),&pid);
	//while(QFileInfo::exists(destpath)==false);

	backgroundcoms.setProgram("rm");
	backgroundcoms.setArguments({"--force",tempfile});
	backgroundcoms.startDetached();

	srcsize=QFileInfo(data.srcFile).size();
	checkTermSize();

	if(srcsize>MINFILESIZE)
		{
			setFileProgress(QFileInfo(destpath).size(),srcsize,data.srcFile,data.destFolder);

			while(true)
				{
					while(QFileInfo(destpath).size()<srcsize)
						{
							checkTermSize();
							setFileProgress(QFileInfo(destpath).size(),srcsize,data.srcFile,data.destFolder,true);
						}
					break;
				}
			setFileProgress(srcsize,srcsize,data.srcFile,data.destFolder,true);
			setOverallProgress((double)copiedFiles,(double)realFileCnt,true);
		}
	else
		{
			setFileProgress(srcsize,srcsize,data.srcFile,data.destFolder,true);
		}
	fflush(NULL);
//
//
//	while(loop==true)
//		{
//			while(QFileInfo(destpath).size()<srcsize)
//				{
//					perc=(unsigned int)(((double)QFileInfo(destpath).size()/(double)srcsize)*100);
//					QTextStream(stdout)<<QString("\rCopied %1B of %2B %3% from '%4' to '%5'\e[K").arg(QFileInfo(destpath).size()).arg(srcsize).arg(perc).arg(data.srcFile).arg(destpath);
//					fflush(NULL);
//					usleep(SLEEPYTIME);
//				}
//			loop=false;
//		}
//
//	QTextStream(stdout)<<QString("\rCopied %1B of %2B 100% from '%3' to '%3'\e[K").arg(QFileInfo(destpath).size()).arg(srcsize).arg(data.srcFile).arg(destpath);
//	fflush(NULL);
}

void makeFileList(QString path)
{
	if(QFileInfo(path).isFile()==true)
		{
			QString filename=QFileInfo(path).fileName();
			QString dirname=destDir+QFileInfo(path).absolutePath().mid(subtractDir.length());

			dataList.push_back({path,dirname,filename});
			realFileCnt++;
			return;
		}

	QString			basedirname=QFileInfo(path).fileName();
	QDir				directory(path);
	QFileInfoList	entries=directory.entryInfoList(QDir::NoDotAndDotDot |QDir::Files|QDir::Dirs|QDir::Hidden);
	for(const QFileInfo &entry : entries)
		{
			if(QFileInfo(entry.absoluteFilePath()).isDir()==true && QFileInfo(entry.absoluteFilePath()).isSymLink()==false)
				{
					dataList.push_back({"",destDir+entry.absoluteFilePath().mid(subtractDir.length()),entry.fileName()});
					makeFileList(entry.absoluteFilePath());
				}
			else
				{
					dataList.push_back({entry.absoluteFilePath(),destDir+entry.absolutePath().mid(subtractDir.length()),entry.fileName()});
					realFileCnt++;
				}
		}
}

void copyAllFiles(void)
{
	QString command;
	QProcess proc;

	for(const fileData &data : dataList)
		{
			if(data.srcFile.isEmpty()==true)
				QProcess::execute("mkdir",{"-p",data.destFolder});

			if(QFileInfo::exists(data.destFolder)==false)
				QProcess::execute("mkdir",{"-p",data.destFolder});

			if(data.srcFile.isEmpty()==false)
				{
					copyFile(data);
					copiedFiles++;
					setOverallProgress((double)copiedFiles,(double)realFileCnt,true);
					pid=-1;
				}
		}
}

void handleSignal(int signal)
{
	showCursor();
	putCursor(1,termRows);
	makeTermSane();
	if(pid!=-1)
		kill(pid,SIGTERM);
	QTextStream(stdout)<<"Terminated ..."<<Qt::endl;
	exit(0);
}

int main(int argc,char **argv)
{
	QCoreApplication	app(argc,argv);

	signal(SIGINT,handleSignal);
	signal(SIGTERM,handleSignal);
	signal(SIGABRT,handleSignal);

	destDir=argv[argc-1];
	dataList.clear();
	hideCursor();

	QTextStream(stdout)<<"Gathering source files ..."<<Qt::endl;
	QString argstr;
	for(int j=1;j<argc-1;j++)
		{
			argstr=argv[j];
			if(QFileInfo(argstr).isDir() && argstr.endsWith('/')==false)
				argstr+="/";
			
			subtractDir=QFileInfo(argstr).path();
			makeFileList(argstr);
		}
		
//	for(const fileData &data : dataList)
//		{
//			qDebug()<<data.srcFile<<data.destFolder<<data.destFile;
//		}

	if(realFileCnt==1)
		{
			oneFile=true;
			boxHite=8;
		}

	if(useCurses==true)
		drawDialogWrap();

	setOverallProgress((double)copiedFiles,(double)realFileCnt,false);
	copyAllFiles();
	showCursor();
	putCursor(1,termRows);
	makeTermSane();
	return(0);
}